classdef StokesBubble < Stokes
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here

    properties
        coord_bubble;
        J;
    end

    %----------------------------------------------------------------------
    methods (Access = public)
        %------------------------------------------------------------------
        function this = copy(this, solver)
            this.V  = solver.V;
            this.P  = solver.P;
            this.J  = solver.J;
        end
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir, mu, f_1, f_2, g, flag_mesh)
            %--------------------------------------------------------------
            this = initialize@Stokes(this,meshdir,mu,f_1,f_2,g,flag_mesh);
            %--------------------------------------------------------------
            meshtriang   = strcat(meshdir, '/mesh.dat');
            meshcoord    = strcat(meshdir, '/xy.dat');
            %--------------------------------------------------------------
            load(meshtriang  , 'mesh'  );
            load(meshcoord   , 'xy'    );
            %--------------------------------------------------------------
            triang = mesh(:,1:3);
            coord  = xy;
            this.coord_bubble=barycenter(this,triang,coord);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% INIT CONDITION
        %------------------------------------------------------------------
        function [u1_0, u2_0] = zeroInitCond(this)
            Nodes = this.V.Nodes;
            u1_0 = zeros(Nodes + size(this.coord_bubble,1),1);
            u2_0 = zeros(Nodes + size(this.coord_bubble,1),1);
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A  = this.mu * this.LinSys.A;
            M  = c  * this.LinSys.M;
            B1 = this.LinSys.B1;
            B2 = this.LinSys.B2;
            totNodes = this.V.Nodes + this.V.Nelem;
            SYSMAT=[A+M                      ,sparse(totNodes,totNodes), B1';
                    sparse(totNodes,totNodes), A+M                     , B2';
                    B1                       , B2                      , sparse(this.P.Nodes,this.P.Nodes)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% PREPRO, PREPARE THE SOLVER 
        %------------------------------------------------------------------
        function [this] = prepro(this)
            %----------
            % compute local basis
            [this.V.Bloc, this.V.Cloc, this.V.Area, this.J] = ...
                                     this.LocalBasis(this.V.Nelem,this.V.triang,this.V.coord);
            this.P.Area = this.V.Area;            
            %----------
            % Compute Matrices
            [M, A, B1, B2]   = BuildSystem(this);
            [rhs, P_bc] = forcing(this);
            this.LinSys.M      = M;
            this.LinSys.A      = A;
            this.LinSys.B1     = B1;
            this.LinSys.B2     = B2;
            this.LinSys.rhs    = rhs;
            this.LinSys.P_bc   = P_bc;
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% LOCAL BASIS + JACOBIAN
        function [Bloc,Cloc,Area,J]=LocalBasis(~,Nelem,triang,coord)
            %--------------------------------------------------------------
            % build local P1 basis functions on triangles 
            % only the coefficients (b,c) multiplying x and y are built
            % \phi(x,y) = a + b x + c y
            %  b_i=y_j-y_k  (i->j->k->i)
            %  c_i=x_k-x_j  (i->j->k->i)
            %--------------------------------------------------------------
            Area=zeros(Nelem,1);
            J=zeros(2,2,Nelem);
            %--------------------------------------------------------------
            Bloc = [-1, 1, 0];
            Cloc = [-1, 0, 1];
            for iel=1:Nelem
                nodes=triang(iel,:);
                p1=coord(nodes(1),:);
                p2=coord(nodes(2),:);
                p3=coord(nodes(3),:);
                A=[1 p1 ; 1 p2 ; 1 p3];
                DetA=det(A);
                %----------------------------------------------------------
%                 J(:,:,iel)=inv([(p2(1)-p1(1)),(p3(1)-p1(1)) ;...
%                                 (p2(2)-p1(2)) ,(p3(2)-p1(2))]);
                J(:,:,iel)=[(p3(2)-p1(2)),-(p3(1)-p1(1)) ;...
                            -(p2(2)-p1(2)) ,(p2(1)-p1(1))]/abs(DetA);
                Area(iel)=abs(DetA)/2;
                %----------------------------------------------------------
            end 
            %--------------------------------------------------------------
        end
       %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        %%% DIRECT STATIONARY SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = DirectStatSolver(this, flag)
            % SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %-------
            SYSMAT   = stiffBuild(this, 0);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs,flag);
            sol = SYSMAT\rhs;
            N_tot = this.V.Nodes+this.V.Nelem;
            uh1   = sol(1:this.V.Nodes); 
            uh2   = sol(N_tot+1:N_tot+this.V.Nodes); 
            p     = sol(2*N_tot+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % TIME DEPENDENT SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs_base  = this.LinSys.rhs;
            N_tot     = this.V.Nodes+this.V.Nelem;
            P_bc      = this.LinSys.P_bc;
            M         = this.LinSys.M;
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*N_tot,1) = rhs_base(1:2*N_tot) + [M * u1_0; M * u2_0]/Dt;
            %-------
            SYSMAT   = stiffBuild(this, 1/Dt);
            [SYSMAT,rhs_1] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
            sol = SYSMAT\rhs_1;
            uh1   = sol(1:N_tot); 
            uh2   = sol(N_tot+1:2*N_tot); 
            p     = sol(2*N_tot+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    % PROTECTED METHODS
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    methods (Access = protected)
        %% IMPOSE BOUNDARY CONDITIONS
        function [stiffMat,rhs] = imposeBC(this,P_bc,stiffMat,rhs,flag)
            %--------------------------------------------------------------
            % impose Dirichle BCs
            % flag: 0 => penalty method;
            %     : 1 => Lifting function;
            if nargin < 5
                flag = 0;
            end
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes + this.V.Nelem;
            NDir_v   = this.V.NDir;
            DirNod_v = this.V.DirNod;
            DirVal_v = this.V.DirVal;
            
            NNeu     = this.V.NNeu;
            NeuNod  = this.V.NeuNod;
            NeuVal   = this.V.NeuVal;
            %-----------------------
            %%% DIRICHLET
            %--------------------------------------------------------------
            switch flag 
                %----------------------------------------------------------
                case 0
                    %------------------------------------------------------
                    penalty=1e10;
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=penalty;
                            rhs((k-1)*Nodes_v+iglob)=penalty*DirVal_v(idir,k);
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                case 1
                    %------------------------------------------------------
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);   
                            stiffMat((k-1)*Nodes_v+iglob,:)=0; 
                            rhs=rhs-DirVal_v(idir,k)*stiffMat(:,(k-1)*Nodes_v+iglob); 
                            rhs((k-1)*Nodes_v+iglob)=DirVal_v(idir, k);
                            stiffMat(:,(k-1)*Nodes_v+iglob)=0;
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
%                     for idir=1:NDir_v
%                         k = 3;
%                         iglob=DirNod_v(idir);   
%                         stiffMat((k-1)*Nodes_v+iglob,:)=0; 
%                         rhs=rhs-this.P.DirVal(idir)*stiffMat(:,(k-1)*Nodes_v+iglob); 
%                         rhs((k-1)*Nodes_v+iglob)=this.P.DirVal(idir);
%                         stiffMat(:,(k-1)*Nodes_v+iglob)=0;
%                         stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
%                     end
                    %------------------------------------------------------
            end
            %------------------------
            %%%% NEUMANN
            for k = 1:2
                for ineu = 1 :NNeu
                    iglob = NeuNod(ineu);
                    rhs((k-1)*Nodes_v+iglob) = rhs((k-1)*Nodes_v+iglob) + NeuVal(ineu,k);
                end
            end
            %%% ZERO MEAN PRESSURE CONDITION IF NO NEUMANN BC
            %--------------------------------------------------------------
            if sum(this.Bound.Check == "Neu") == 0
                if flag == 0
                    index = 2*Nodes_v + 1;
                else 
                    index = 2*Nodes_v+this.P.Nodes+1;
                end
            stiffMat(index,1:2*Nodes_v)=0;
            stiffMat(index,2*Nodes_v+1:end)=P_bc;
            rhs(index)=0;
            end
%             %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD THE SYSTEM MATRIX
        function [M, A, B1, B2] = BuildSystem(this)
            %--------------------------------------------------------------
            Nelem  = this.V.Nelem;
            Nodes  = this.V.Nodes;
            triang = this.V.triang;
            Bloc   = this.V.Bloc;
            Cloc   = this.V.Cloc;
            Area   = this.V.Area;
            Jac    = this.J;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem*16,1);i_sparse_B=zeros(Nelem*12,1);
            j_sparse = zeros(Nelem*16,1);j_sparse_B=zeros(Nelem*12,1);
            H_val    = zeros(Nelem*16,1);
            M_val    = zeros(Nelem*16,1);
            B1_val   = zeros(Nelem*12,1);
            B2_val   = zeros(Nelem*12,1);
            %--------------------------------------------------------------
            it=1; it_B=1;
            bubble = Nodes*ones(Nelem,1)+(1:Nelem)';
            ELEM   = [triang,bubble];
            for iel=1:Nelem
                %----------------------------------------------------------
                for iloc=1:4
                    %------------------------------------------------------
                    iglob=ELEM(iel,iloc);
                    for jloc=1:4
                        %--------------------------------------------------
                        jglob        = ELEM(iel,jloc);
                        i_sparse(it) = iglob;
                        j_sparse(it) = jglob;
                        %--------------------------------------------------
                        if iloc<4 && jloc<4 %Standard case
                            H_val(it) = ([Bloc(iloc), Cloc(iloc)]*Jac(:,:,iel))*...
                                        ([Bloc(jloc), Cloc(jloc)]*Jac(:,:,iel))'*Area(iel);
                            %----------------------------------------------
                            if iloc==jloc
                                M_val(it) = Area(iel)/6;
                            else
                                M_val(it) = Area(iel)/12;
                            end
                            %----------------------------------------------
                            i_sparse_B(it_B)=iglob;
                            j_sparse_B(it_B)=jglob;
                            %----------------------------------------------
                            B1_val(it_B)=-1/3*Area(iel)*[Bloc(jloc),Cloc(jloc)]*Jac(:,1,iel);
                            B2_val(it_B)=-1/3*Area(iel)*[Bloc(jloc),Cloc(jloc)]*Jac(:,2,iel);
                            %----------------------------------------------
                            it_B=it_B+1;
            %                  BUBBLE
                        %--------------------------------------------------
                        elseif (iloc==1 && jloc==4) || (iloc==4 && jloc==1)
                            H_val(it)=0+0+0; 
                            M_val(it)=3/40*2*Area(iel);
                        %--------------------------------------------------
                        elseif (iloc==2 && jloc==4) || (iloc==4 && jloc==2)
                            H_val(it)=0+0+0;
                            M_val(it)= 3/40*2*Area(iel);
                        %--------------------------------------------------
                        elseif (iloc==3 && jloc==4) || (iloc==4 && jloc==3)
                            H_val(it)=0+0+0; 
                            M_val(it)=3/40*2*Area(iel);
                        %--------------------------------------------------
                        elseif (iloc==4 && jloc==4)
                            H_val(it)=(81/20*Jac(1,1,iel)^2+Jac(1,1,iel)*Jac(2,1,iel)*(81/40+81/40)+81/20*Jac(2,1,iel)^2+...
                                +81/20*Jac(1,2,iel)^2+Jac(1,2,iel)*Jac(2,2,iel)*(81/40+81/40)+Jac(2,2,iel)^2*81/20)*2*Area(iel);
                            M_val(it)=81/560*2*Area(iel);
                        %--------------------------------------------------
                        end
                        it=it+1;
                        if iloc==4
                             continue
                        elseif jloc==4 
                            %----------------------------------------------
                             i_sparse_B(it_B)=iglob;
                             j_sparse_B(it_B)=jglob;
                             %---------------------------------------------
                             if     iloc==1
                                 B1_val(it_B)=(-9/40*Jac(1,1,iel)-9/40*Jac(2,1,iel))*2*Area(iel);
                                 B2_val(it_B)=(-9/40*Jac(1,2,iel)-9/40*Jac(2,2,iel))*2*Area(iel);
                             elseif iloc==2
                                 B1_val(it_B)=(9/40*Jac(1,1,iel)+0)*2*Area(iel);
                                 B2_val(it_B)=(9/40*Jac(1,2,iel)+0)*2*Area(iel); 
                             elseif iloc==3
                                 B1_val(it_B)=(0+9/40*Jac(2,1,iel))*2*Area(iel);
                                 B2_val(it_B)=(9/40*Jac(2,2,iel)+0)*2*Area(iel);
                             end
                             %---------------------------------------------
                             it_B=it_B+1;
                        end
                        %--------------------------------------------------
                    end % jloc
                end % iloc
            end % Nelem
            %--------------------------------------------------------------
            A  = sparse(i_sparse,j_sparse,H_val);
            M  = this.rho*sparse(i_sparse,j_sparse,M_val);
            B1 = sparse(i_sparse_B,j_sparse_B,B1_val);
            B2 = sparse(i_sparse_B,j_sparse_B,B2_val);
            %--------------------------------------------------------------
        end
       %-------------------------------------------------------------------
        %% FORCING
        function [rhs, P_bc]=forcing(this)
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %--------------------------------------------------------------
            Nodes    = this.V.Nodes;
            Nelem    = this.V.Nelem;
            coord    = this.V.coord;
            triang   = this.V.triang;
            Area     = this.V.Area;
            N_tot    = Nodes+Nelem;
            rhs      = zeros(2*N_tot+this.P.Nodes,1);
            P_bc     = zeros(this.P.Nodes,1);
            bubble   = Nodes*ones(Nelem,1)+(1:Nelem)';
            ELEM     = [triang,bubble];
            %--------------------------------------------------------------
            for iel=1:Nelem
                for iloc=1:4
                    iglob=ELEM(iel,iloc);
                    if iloc<4
                        x=coord(iglob,1); y=coord(iglob,2);
                        rhs(iglob)         = rhs(iglob)+...
                                             this.f_1(x,y)/3*Area(iel);
                        rhs(N_tot+iglob)   = rhs(N_tot+iglob)+...
                                             this.f_2(x,y)/3*Area(iel);
                        rhs(2*N_tot+iglob) = rhs(2*N_tot+iglob)+...
                                             this.g(x,y)/3*Area(iel);
                        
                        P_bc(iglob)        = P_bc(iglob)+Area(iel)/3;
                    else
                        x = this.coord_bubble(iglob-Nodes,1); 
                        y = this.coord_bubble(iglob-Nodes,2);
                        rhs(iglob)       = rhs(iglob)+27/60*Area(iel)*this.f_1(x,y);
                        rhs(N_tot+iglob) = rhs(N_tot+iglob)+27/60*Area(iel)*this.f_2(x,y);
                    end
                end
            end
        end
    end
    %----------------------------------------------------------------------
    methods(Access = private)
        %------------------------------------------------------------------
        function coord_centers = barycenter(~,triangles,coords)
            %--------------------------------------------------------------
            coord_centers = zeros(size(triangles,1),2);
            for i = 1 : size(triangles,1)
                verteces = triangles(i,:);
                x_c = sum(coords(verteces,1))/3;
                y_c = sum(coords(verteces,2))/3;
                coord_centers(i,:) = [x_c, y_c];
            end
            %--------------------------------------------------------------
        end
    end
end
