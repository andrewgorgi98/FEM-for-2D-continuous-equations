%%% Main script for the resolution of Stokes problem
clear all; close all; clc;

N = [10, 50,100,150];
nn = length(N);
tempo = zeros(nn,3);
tempo1 = zeros(nn,3);
for itmesh = 1:nn
    for trial = 1:5
% Define the 2D mesh and equation BC's and coefficients
% meshdir="mesh" + num2str(itmesh);
meshdir="meshN/mesh" + N(itmesh);
% Solver.UniformMesh([0,1],[0,1],N(itmesh))
nfig   = 1;

%--------------------------------------------------------------------------
% SET PARAMETERS
%--------------------------------------------------------------------------
see_mesh  = false; % true to see the mesh
flag_BC   = 1; % BC: 0 for FAST penalty method
               %   : 1 for ACCURATE lifting function method
delta     = 0.01; % <--- ONLY FOR STOKESSTABILIZED 
%----------------------
%%% physical parameters
%-----------------------
mu           = 1;
Dt           = 1;
MaxTimeSteps = 1;

c = 1/Dt;
% c= 0;
%-----------------------
%%% PRIMO PROBLEMA
%-----------------------
u_1 = @(x,y) -cos(2*pi.*x).*sin(2*pi.*y)+sin(2*pi.*y);
u_2 = @(x,y) sin(2*pi.*x).*cos(2*pi.*y)-sin(2*pi.*x);
p   = @(x,y) 2*pi.*(cos(2*pi.*y)-cos(2*pi.*x));
f_1 = @(x,y) c.*u_1(x,y)-4*mu*pi^2.*sin(2*pi.*y).*(2*cos(2*pi.*x)-1)+4*pi^2.*sin(2*pi.*x);
f_2 = @(x,y) c.*u_2(x,y)+4*mu*pi^2.*sin(2*pi.*x).*(2*cos(2*pi.*y)-1)-4*pi^2.*sin(2*pi.*y);
g   = @(x,y) 0;
%--------------------------------------------------------------------------
% INITIALIZE SOLVER
%--------------------------------------------------------------------------
disp('INITIALIZE SOLVER');
disp('-----------------------------------'); disp('-----------------------------------');
Stokes = StokesStabilized();
tstart= cputime; tic;
Stokes = Stokes.initialize(meshdir, mu, f_1, f_2, g, delta, see_mesh);

Dirval_p = zeros(Stokes.V.NDir,1);
for i=1:Stokes.V.NDir
    iglob = Stokes.V.DirNod(i);
    Dirval_p(i) = p(Stokes.V.coord(iglob,1),Stokes.V.coord(iglob,2));
end
Stokes.P.DirVal = Dirval_p;
Trial(trial,1) = cputime - tstart;
Trial1(trial,1) = toc;
%--------------------------------------------------------------------------
% set BC
%--------------------------------------------------------------------------
tic;
tstart = cputime;
disp('-----------------------------------')
disp('SET BC');
disp('-----------------------------------'); disp('-----------------------------------');

% Upper wall
% Stokes = Stokes.setDirBC(1, [0.0; 1.0],1.0,[1,0]);

% Lower wall

% Left wall

% Right wall

% toc;
%--------------------------------------------------------------------------
% PREPRO
%--------------------------------------------------------------------------
% tic;
disp('-----------------------------------')
disp('PREPRO');
disp('-----------------------------------'); disp('-----------------------------------');
Stokes = Stokes.prepro;

Trial(trial,2)=cputime-tstart;
Trial1(trial,2)=toc;

[uh1, uh2] = Stokes.zeroInitCond();

%%% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%%  LAUNCH SOLVER
for timestep = 1 : MaxTimeSteps
%--------------------------------------------------------------------------
% SOLVE
%--------------------------------------------------------------------------
% tic;
tstart = cputime;
disp('-----------------------------------')
disp('SOLVE MASTER PROBLEM');
disp('-----------------------------------');disp('-----------------------------------');
[uh1, uh2, ph] = Stokes.OneStepSolver(uh1, uh2, Dt, flag_BC);
% [uh1, uh2, ph] = Stokes.DirectStatSolver(flag_BC);
Trial(trial,3) = cputime-tstart;
Trial1(trial,3) = toc;


end
    end
tempo(itmesh,1) = mean(Trial(:,1));
tempo1(itmesh,1) = mean(Trial1(:,1));
tempo(itmesh,2) = mean(Trial(:,2));
tempo1(itmesh,2) = mean(Trial1(:,2));
tempo(itmesh,3) = mean(Trial(:,3));
tempo1(itmesh,3) = mean(Trial1(:,3));

err_v1(itmesh) = Stokes.evalErr(uh1,u_1,Stokes.V);
err_v2(itmesh) = Stokes.evalErr(uh2,u_2,Stokes.V);
err_p(itmesh) = Stokes.evalErr(ph,p,Stokes.P);
h(itmesh) = Stokes.Bound.EdgesLength(1);
Nelem(itmesh)= Stokes.P.Nelem;
end
% CONVERGENCE VELOCITY ESTIMATION
figure(10)
nfig = nfig + 1;
loglog(h, err_v1, ' b-')
hold on
loglog(h, err_v2, ' k-')
loglog(h, err_p, ' g-')
xlabel('max edge length'); ylabel('L_2 norm of the error');
legend('err V_1','err V_2', 'err_p');
hold off

V_v1 =(log(err_v1(2:end))-log(err_v1(1:end-1)))./(log(h(2:end))-log(h(1:end-1)));
V_v2 =(log(err_v2(2:end))-log(err_v2(1:end-1)))./(log(h(2:end))-log(h(1:end-1)));
V_p  =( log(err_p(2:end))-log(err_p(1:end-1))) ./(log(h(2:end))-log(h(1:end-1)));
% Stokes.PrintRes(uh1,uh2,ph,3);
% Stokes.PrintResIso(uh1,uh2,ph,6);


%%% CPU TIME
figure(11)
loglog(Nelem,tempo(:,1), 'b-');
hold on
loglog(Nelem,tempo(:,2), 'k-');
loglog(Nelem,tempo(:,3), 'y-');

xlabel('Pressure Elements'); ylabel('CPU time');
legend('initialization', 'prepro', 'solving');
hold off

%%% WALL TIME
figure(12)
loglog(Nelem,tempo1(:,1), 'b-');
hold on
loglog(Nelem,tempo1(:,2), 'k-');
loglog(Nelem,tempo1(:,3), 'y-');

xlabel('Pressure Elements'); ylabel('Wall time');
legend('initialization', 'prepro', 'solving');
hold off
