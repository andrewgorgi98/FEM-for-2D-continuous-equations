%%% Main script for the resolution of Stokes problem
clear all; close all; clc;

%--------------------
%%% UNIFORM MESH
%--------------------
% N = 101;
% Solver.UniformMesh([0,1],[0,1],N); % <- creates the mesh in the appropriate folder
% meshdir = "meshN/mesh" + N;

%-------------------
%%% PROVIDED MESH
%-------------------
meshdir = "mesh2";

nfig   = 1;
%--------------------------------------------------------------------------
% SET PARAMETERS
%--------------------------------------------------------------------------
see_mesh  = false; % true to see the mesh
flag_BC   = 1; % BC: 0 for FAST penalty method
               %   : 1 for ACCURATE lifting function method
delta     = 0.01; % <--- ONLY FOR STOKESSTABILIZED 
%----------------------
%%% physical parameters
%-----------------------
mu           = 0.01;
rho          = 1;
Dt           = 1.0;
MaxTimeSteps = 20;

c = 1/Dt;
%-----------------------
%%% PRIMO PROBLEMA
%-----------------------
% u_1 = @(x,y) -cos(2*pi.*x).*sin(2*pi.*y)+sin(2*pi.*y);
% u_2 = @(x,y) sin(2*pi.*x).*cos(2*pi.*y)-sin(2*pi.*x);
% p   = @(x,y) 2*pi.*(cos(2*pi.*y)-cos(2*pi.*x));
% f_1 = @(x,y) c.*u_1(x,y)-4*mu*pi^2.*sin(2*pi.*y).*(2*cos(2*pi.*x)-1)+4*pi^2.*sin(2*pi.*x);
% f_2 = @(x,y) c.*u_2(x,y)+4*mu*pi^2.*sin(2*pi.*x).*(2*cos(2*pi.*y)-1)-4*pi^2.*sin(2*pi.*y);
% g   = @(x,y) 0;
%-----------------------
%%% SECONDO PROBLEMA
%-----------------------
f_1 = @(x,y) 0;
f_2 = @(x,y) 0;
g   = @(x,y) 0;
%--------------------------------------------------------------------------
% INITIALIZE SOLVER
%--------------------------------------------------------------------------
disp('INITIALIZE SOLVER');
disp('-----------------------------------'); disp('-----------------------------------');

%%% STOKES
Stokes = StokesP1P2();
tic;
Stokes = Stokes.initialize(meshdir, mu, f_1, f_2, g, see_mesh);
toc;

%%% NAVIER STOKES
% Stokes = NavierStokes();
% tau = 0.00001;
% tic;
% Stokes = Stokes.initialize(meshdir, mu, rho, f_1, f_2, g, tau, see_mesh);
% toc;
%--------------------------------------------------------------------------
% set BC
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('SET BC');
disp('-----------------------------------'); disp('-----------------------------------');

% Upper wall
Stokes = Stokes.setDirBC(2, [0.3; 0.7],0.0,@(x,y)[(y-0.3)*(0.7-y)/0.04,0]);

% Lower wall

% Left wall

% Right wall
Stokes = Stokes.setNeuBC(2, [0.3; 0.7],1.0,[0, 0]);

toc;
%--------------------------------------------------------------------------
% PREPRO
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('PREPRO');
disp('-----------------------------------'); disp('-----------------------------------');
Stokes = Stokes.prepro;
toc;

[uh1, uh2] = Stokes.zeroInitCond();

%%% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
%%  LAUNCH SOLVER
for timestep = 1 : MaxTimeSteps
%--------------------------------------------------------------------------
% SOLVE
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('SOLVE MASTER PROBLEM');
disp('-----------------------------------');disp('-----------------------------------');
[uh1, uh2, ph] = Stokes.OneStepSolver(uh1, uh2, Dt, flag_BC);
% [uh1, uh2, ph] = Stokes.StatSolver(uh1,uh2,flag_BC);
% [uh1, uh2, ph] = Stokes.DirectStatSolver(flag_BC);
toc;

%-----------------------
%%% PLOT VECTOR FIELS/STREAMLINES
%-----------------------
figure(2)
for iedge = 1:size(Stokes.Bound.Edges,1)
    p1 = Stokes.V.coord(Stokes.Bound.Edges(iedge,1),:);
    p2 = Stokes.V.coord(Stokes.Bound.Edges(iedge,2),:);
    plot([p1(1), p2(1)], [p1(2), p2(2)], 'r-');
    hold on;
end

[x,y] = meshgrid(Stokes.X_limits(1):0.1:Stokes.X_limits(2), ...
                 Stokes.Y_limits(1):0.1:Stokes.Y_limits(2));
u = zeros(size(x)); v = zeros(size(x));
for i = 1:numel(x)
    [u(i), v(i)]= Stokes.getApproxValue_v([x(i);y(i)],uh1,uh2);
    if norm([u(i), v(i)]) < 1e-3
        u(i) = 0;
        v(i) = 0;
    end
end
quiver(x,y,u,v, 'Color', 'b');
streamslice(x,y,u,v);
hold off;


flux = 0;
for iedge = 1 : length(Stokes.Bound.Edges)
    for iloc = 1 : 2
        iglob = Stokes.Bound.Edges(iedge,iloc);
        flux = flux+Stokes.Bound.EdgesLength(iedge)*([uh1(iglob),uh2(iglob)]*Stokes.Bound.ExtNormal(iedge))/2;
    end
end
% Error:
fprintf('mass in - mass out = %7.4e \n', norm(flux));
end
Stokes.PrintRes(uh1,uh2,ph,3);
Stokes.PrintResIso(uh1,uh2,ph,6);

