classdef Stokes < Solver
    %----------------------------------------------------------------------
    properties
        mu;
        rho = 1;
        f_1;
        f_2;
        g;
    end
    %----------------------------------------------------------------------
    methods (Access = public)
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir, mu, f_1, f_2, g, flag_mesh)
            %--------------------------------------------------------------
            this = initialize@Solver(this,meshdir,flag_mesh);
            %%% set coefficients    
            this.mu  = mu;
            this.f_1 = f_1;
            this.f_2 = f_2;
            this.g   = g;
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A  = this.mu * this.LinSys.A;
            M  = c  * this.LinSys.M;
            B1 = this.LinSys.B1;
            B2 = this.LinSys.B2;

            SYSMAT=[A+M                              ,sparse(this.V.Nodes,this.V.Nodes), B1';
                    sparse(this.V.Nodes,this.V.Nodes), A+M                             , B2';
                    B1                               , B2                              , sparse(this.P.Nodes,this.P.Nodes)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% PREPRO, PREPARE THE SOLVER 
        %------------------------------------------------------------------
        function this = prepro(this)
            %--------------------------------------------------------------
            % compute local basis
            [this.V.Bloc, this.V.Cloc, this.V.Area] = ...
                                     this.LocalBasis(this.V.Nelem,this.V.triang,this.V.coord);
            [this.P.Bloc, this.P.Cloc, this.P.Area] = ...
                                     this.LocalBasis(this.P.Nelem,this.P.triang,this.P.coord);
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        %%% DIRECT STATIONARY SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = DirectStatSolver(this, flag)
            % SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %-------
            SYSMAT   = stiffBuild(this, 0);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% TIME DEPENDENT SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = TimeDepSolver(this, u1_0, u2_0, Dt, T_end, flag)
            time = 0;
            while time < T_end
                [u1_0, u2_0, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                time = time + Dt;
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% STEADY STATE TROUGHT TIME ITERATIONS
        %------------------------------------------------------------------
        function [uh1, uh2, p] = StatSolver(this, flag, u1_0, u2_0)
            if nargin == 2
                [u1_0, u2_0] = this.zeroInitCond();
            end
            toll   = 1e-2;
            scarto = toll + 1;
            time   = 0;
            Dt = 0.1;
            while scarto > toll
                [u1_0_new, u2_0_new, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                scarto = sqrt(this.evalErr(u1_0_new,u1_0,this.V)^2 + this.evalErr(u2_0_new,u2_0,this.V)^2)/2;
                u1_0 = u1_0_new;
                u2_0 = u2_0_new;
                time = time + Dt;
                if time > Dt * 300
                    warning('Couldn''t find steady state, instability or too high time interval');
                    break;
                end
            end
            if scarto < toll
                fprintf('\nSteady state achieved in less than %4.2 seconds\n', time);
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % TIME DEPENDENT SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs_base  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            M    = this.LinSys.M;
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*this.V.Nodes,1) = rhs_base(1:2*this.V.Nodes) + [M * u1_0; M * u2_0]/Dt;
            %-------
            SYSMAT   = stiffBuild(this, 1/Dt);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    % PROTECTED METHODS
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    methods (Access = protected)
        %% IMPOSE BOUNDARY CONDITIONS
        function [stiffMat,rhs] = imposeBC(this,P_bc,stiffMat,rhs,flag)
            %--------------------------------------------------------------
            % impose Dirichle BCs
            % flag: 0 => penalty method;
            %     : 1 => Lifting function;
            if nargin < 5
                flag = 0;
            end
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            NDir_v   = this.V.NDir;
            DirNod_v = this.V.DirNod;
            DirVal_v = this.V.DirVal;
            
            NNeu     = this.V.NNeu;
            NeuNod   = this.V.NeuNod;
            NeuVal   = this.V.NeuVal;
            %-----------------------
            %%% DIRICHLET
            %--------------------------------------------------------------
            switch flag 
                %----------------------------------------------------------
                case 0
                    %------------------------------------------------------
                    penalty=1e10;
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=penalty;
                            rhs((k-1)*Nodes_v+iglob)=penalty*DirVal_v(idir,k);
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                case 1
                    %------------------------------------------------------
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);   
                            stiffMat((k-1)*Nodes_v+iglob,:)=0; 
                            rhs=rhs-DirVal_v(idir,k)*stiffMat(:,(k-1)*Nodes_v+iglob); 
                            rhs((k-1)*Nodes_v+iglob)=DirVal_v(idir, k);
                            stiffMat(:,(k-1)*Nodes_v+iglob)=0;
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
%                     for idir=1:NDir_v
%                         k = 3;
%                         iglob=DirNod_v(idir);   
%                         stiffMat((k-1)*Nodes_v+iglob,:)=0; 
%                         rhs=rhs-this.P.DirVal(idir)*stiffMat(:,(k-1)*Nodes_v+iglob); 
%                         rhs((k-1)*Nodes_v+iglob)=this.P.DirVal(idir);
%                         stiffMat(:,(k-1)*Nodes_v+iglob)=0;
%                         stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
%                     end
                    %------------------------------------------------------
            end
            %------------------------
            %%%% NEUMANN
            for k = 1:2
                for ineu = 1 :NNeu
                    iglob = NeuNod(ineu);
                    rhs((k-1)*Nodes_v+iglob) = rhs((k-1)*Nodes_v+iglob) + NeuVal(ineu,k);
                end
            end
            %%% ZERO MEAN PRESSURE CONDITION IF NO NEUMANN BC
            %--------------------------------------------------------------
            if sum(this.Bound.Check == "Neu") == 0
                if flag == 0
                    index = 2*Nodes_v + 1;
                else 
                    index = 2*Nodes_v+this.P.Nodes+1;
                end
            stiffMat(index,1:2*Nodes_v)=0;
            stiffMat(index,2*Nodes_v+1:end)=P_bc;
            rhs(index)=0;
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% FORCING
        function [rhs, P_bc] = forcing(this)
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            coord_v  = this.V.coord;
            triang_v = this.V.triang;
            Area_v   = this.V.Area;
            triang_p = this.P.triang;
            Area_p   = this.P.Area;
            rhs      = zeros(2*Nodes_v+this.P.Nodes,1);
            P_bc     = zeros(this.P.Nodes,1);
            %--------------------------------------------------------------
            for iel=1:this.V.Nelem
                %----------------------------------------------------------
                for iloc=1:3
                    iglob=triang_v(iel,iloc);
                    x=coord_v(iglob,1); y=coord_v(iglob,2);
                    rhs(iglob)=rhs(iglob)+...
                        this.f_1(x,y)/3*Area_v(iel);
                    rhs(Nodes_v+iglob)=rhs(Nodes_v+iglob)+...
                        this.f_2(x,y)/3*Area_v(iel);
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            for iel=1:this.P.Nelem
                for iloc=1:3
                    iglob=triang_p(iel,iloc);
                    rhs(2*Nodes_v+iglob)=rhs(2*Nodes_v+iglob)+this.g(x,y)/3*Area_p(iel);
                    P_bc(iglob)=P_bc(iglob)+Area_p(iel)/3;
                end
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
end