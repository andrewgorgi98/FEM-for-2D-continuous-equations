classdef StokesStabilized < Stokes
    
    properties
        delta;
        h;
    end
    
    methods (Access = public)
        %------------------------------------------------------------------
        function  this = copy(this, solver)
            this = copy@Solver(this,solver);
        end
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir, mu, f_1, f_2, g, delta, flag_mesh)
            %--------------------------------------------------------------
            this = initialize@Stokes(this,meshdir,mu,f_1,f_2,g,flag_mesh);
            %--------------------------------------------------------------
            this.delta = delta;
            %---------------------
            %max length of each triangle
            Nelem = this.V.Nelem;
            this.h = ones(Nelem,1);
            P = zeros(3,2); d=zeros(3,1);
            %----------------------------
            for iel=1:Nelem
                %-----------
                for iloc=1:3
                    xglob=this.V.triang(iel,iloc);
                    P(iloc,:)=this.V.coord(xglob);
                end
                %-----------
                for i=1:2
                    d(i)=norm(P(i,:)-P(i+1,:));
                end
                %----------
                d(3)=norm(P(1,:)-P(3,:));
                this.h(iel)=max(d);
            %----------------------------
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A  = this.mu * this.LinSys.A;
            M  = c  * this.LinSys.M;
            B1 = this.LinSys.B1; 
            BC1 = B1;% + this.delta*this.LinSys.BC1'*c;
            B2 = this.LinSys.B2; 
            BC2 = B2;% + this.delta*this.LinSys.BC2'*c;
            C  = this.LinSys.C;

            SYSMAT=[A+M                              ,sparse(this.V.Nodes,this.V.Nodes), B1';
                    sparse(this.V.Nodes,this.V.Nodes), A+M                             , B2';
                    BC1                              , BC2                             , -C];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% PREPRO, PREPARE THE SOLVER 
        %------------------------------------------------------------------
        function this = prepro(this)
            %----------
            this = prepro@Stokes(this);
            %----------
            % Compute Matrices
            [M, A, B1, B2, C, BC1, BC2]   = BuildStiffness(this);
            [rhs, P_bc] = forcing(this);
            this.LinSys.M      = M;
            this.LinSys.A      = A;
            this.LinSys.B1     = B1;
            this.LinSys.B2     = B2;
            this.LinSys.C      = C;
            this.LinSys.BC1    = BC1;
            this.LinSys.BC2    = BC2;
            this.LinSys.rhs    = rhs;
            this.LinSys.P_bc   = P_bc;
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % TIME DEPENDENT SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs_base  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            M    = this.LinSys.M;
            BC1  = this.LinSys.BC1;
            BC2  = this.LinSys.BC2;
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*this.V.Nodes,1) = rhs_base(1:2*this.V.Nodes) + [M * u1_0; M * u2_0]/Dt;
            rhs_1(2*this.V.Nodes+1:end,1) = rhs_1(2*this.V.Nodes+1:end,1) + this.delta*(BC1'*u1_0+BC2'*u2_0)/Dt;
            %-------
            SYSMAT   = stiffBuild(this, 1/Dt);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    % PROTECTED METHODS
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    methods (Access = protected)
        %------------------------------------------------------------------
        %% FORCING
        function [rhs, P_bc] = forcing(this)
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %--------------------------------------------------------------
            Nodes  = this.V.Nodes;
            coord  = this.V.coord;
            triang = this.V.triang;
            Area   = this.V.Area;
            rhs     = zeros(3*Nodes,1);
            P_bc    = zeros(Nodes,1);
            
            G = zeros(Nodes,1);
            %--------------------------------------------------------------
            for iel=1:this.V.Nelem
                %----------------------------------------------------------
                for iloc=1:3
                    iglob=triang(iel,iloc);
                    x=coord(iglob,1); y=coord(iglob,2);
                    rhs(iglob)=rhs(iglob)+...
                        this.f_1(x,y)/3*Area(iel);
                    rhs(Nodes+iglob)=rhs(Nodes+iglob)+...
                        this.f_2(x,y)/3*Area(iel);
                    rhs(2*Nodes+iglob)=rhs(2*Nodes+iglob)+...
                        this.g(x,y)/3*Area(iel);
                    P_bc(iglob)=P_bc(iglob)+Area(iel)/3;
                    
                    G(iglob)=G(iglob)-this.delta*this.h(iel)^2*(this.f_1(x,y)*this.V.Bloc(iel,iloc)+...
                             this.f_2(x,y)*this.V.Cloc(iel,iloc))/3*Area(iel);
                end
            end
            %-----------------------------------------------
            rhs(2*Nodes+1:end)=rhs(2*Nodes+1:end)+G;
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD THE MATRICES
        function [M, A, B1, B2, C, BC1, BC2] = BuildStiffness(this)
            %--------------------------------------------------------------
            Nelem  = this.V.Nelem;
            triang = this.V.triang;
            Bloc   = this.V.Bloc;
            Cloc   = this.V.Cloc;
            Area   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem*9,1);
            j_sparse = zeros(Nelem*9,1);
            H_val    = zeros(Nelem*9,1);
            M_val    = zeros(Nelem*9,1);
            B1_val   = zeros(Nelem*9,1);
            BC1_val = zeros(Nelem*9,1);
            B2_val   = zeros(Nelem*9,1);
            BC2_val = zeros(Nelem*9,1);
            C_val    = zeros(Nelem*9,1);
            %--------------------------------------------------------------
            it=1; 
            for iel=1:Nelem
                %----------------------------------------------------------
                for iloc=1:3
                    %------------------------------------------------------
                    iglob=triang(iel,iloc);
                    for jloc=1:3
                        %--------------------------------------------------
                        jglob        = triang(iel,jloc);
                        i_sparse(it) = iglob;
                        j_sparse(it) = jglob;
                        %--------------------------------------------------
                        %%% DIFFUSION
                        %------------
                        H_val(it) = (Bloc(iel,iloc)*Bloc(iel,jloc)+...
                                     Cloc(iel,iloc)*Cloc(iel,jloc))*Area(iel);
                        %----------------------------------------------
                        %%% MASS
                        %-------------
                        if iloc==jloc
                            M_val(it) = Area(iel)/6;
                        else
                            M_val(it) = Area(iel)/12;
                        end
                        %----------------------------------------------
                        %%% DIVERGENCE/PRESSURE GRADIENT
                        %----------------
                        B1_val(it)=-1/3*Area(iel)*Bloc(iel,jloc);
                        B2_val(it)=-1/3*Area(iel)*Cloc(iel,jloc);
                        BC1_val(it) = B1_val(it)*this.h(iel)^2;
                        BC2_val(it) = B2_val(it)*this.h(iel)^2;
                        %----------------------------------------------
                        %%% STABILIZATION
                        %----------------
                        C_val(it)=this.delta*this.h(iel)^2*(Bloc(iel,iloc)*Bloc(iel,jloc)+...
                                    Cloc(iel,iloc)*Cloc(iel,jloc))*Area(iel);
                        it=it+1;
                        %--------------------------------------------------
                    end % jloc
                end % iloc
            end % Nelem
            %--------------------------------------------------------------
            A  = sparse(i_sparse,j_sparse,H_val);
            M  = this.rho*sparse(i_sparse,j_sparse,M_val);
            B1 = sparse(i_sparse,j_sparse,B1_val);
            B2 = sparse(i_sparse,j_sparse,B2_val);
            C  = sparse(i_sparse,j_sparse,C_val);
            
            BC1 = sparse(i_sparse,j_sparse,BC1_val);
            BC2 = sparse(i_sparse,j_sparse,BC2_val);
            %--------------------------------------------------------------
        end
    end
end

