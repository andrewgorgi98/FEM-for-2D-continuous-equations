classdef StokesP1P2 < Stokes
    %   StokesP1P2 Solver of Stokes problem with a P1-iso-P2 approach
    %   Find nodal values of solution (u,p) to 
    %   u_t - /mu*/div /grad(u) + /grad(p) = f
    %                           div(u) = g 
    %----------------------------------------------------------------------
    properties
        connectivity;
    end
    %----------------------------------------------------------------------
    methods (Access = public)
        %------------------------------------------------------------------
        function  this = copy(this, solver)
            this = copy@Solver(this,solver);
            this.connectivity  = solver.connectivity;
        end
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir, mu, f_1, f_2, g, flag_mesh)
            % Construct an instance of this class
            %   Detailed explanation goes here
            % meshdir: name of the folder which contains the mesh
            % nfig: number of the first free figure panel
            
%             mesh=[];
            meshtriang   = strcat(meshdir, '/mesh.dat');
            meshcoord    = strcat(meshdir, '/xy.dat');
            meshBoundNod = strcat(meshdir, '/dirtot.dat');
            %--------------------------------------------------------------
            load(meshtriang  , 'mesh'  );
            load(meshcoord   , 'xy'    );
            load(meshBoundNod, 'dirtot');
            BoundNodes = dirtot(:,1);
            this.P.DirNod = BoundNodes;
            %--------------------------------------------------------------
            triang = mesh(:,1:3);
            coord  = xy;
            Nelem_p                   = length(triang(:,1));
            Nodes_p                   = size(coord,1);
            coord_v                   = zeros(Nodes_p+Nelem_p*3,2);
            coord_v(1:Nodes_p,:)      = coord;
            triang_v                  = zeros(Nelem_p*4,3);
            this.connectivity         = zeros(Nelem_p,4);
            count                     = Nodes_p+1;
            
            BoundEdges                = zeros(length(BoundNodes)*2,2);
            BCcount                   = length(BoundNodes)+1;
            BoundExtNormal            = zeros(length(BoundEdges),2);
            EdgeCount                 = 0;
            IsCreated = zeros(Nodes_p,Nodes_p); % check if arc iglob-jglob has already been selected
                                                % and stores entry index
            IsBC      = zeros(Nodes_p,1);
            IsBC_new  = zeros(Nelem_p*6,1);
            IsBC(BoundNodes) = 1;
            
            for iel=1:Nelem_p
                verteces = triang(iel,:);
                vcs      = coord(verteces,:);
                iglob       = zeros(1,3);
                %%% id(1) = middle of arc 1-2
                %%% id(2) = middle of arc 2-3
                %%% id(3) = middle of arc 3-1
                for iloc=1:3
                    iarc = verteces(iloc); jarc = verteces(mod_n(iloc+1,3));
                    flag = IsCreated(iarc,jarc);
                    if flag == 0
                        IsCreated(iarc,jarc) = count;
                        IsCreated(jarc,iarc) = count;
                        newpoint = (vcs(iloc,:)+ vcs(mod_n(iloc+1,3),:))/2;
                        coord_v(count,:) = newpoint;
                        iglob(iloc)      = count;
                        %-------------
                        %%% BC 
                        if IsBC(iarc) && IsBC(jarc)
                            BoundNodes(BCcount) = count;
                            thirdNode = verteces(mod_n(iloc + 2,3));
                            normal    = this.extNormal(coord(iarc,:), coord(jarc,:), coord(thirdNode,:));
                            
                            EdgeCount = EdgeCount + 1;
                            BoundEdges(EdgeCount,:) = [iarc, count];
                            BoundExtNormal(EdgeCount,:)  = normal;
                            IsBC_new(count) = EdgeCount;
                            
                            EdgeCount = EdgeCount + 1;
                            BoundEdges(EdgeCount,:) = [count, jarc];
                            BoundExtNormal(EdgeCount,:)  = normal;
                            
                            BCcount = BCcount+1;
                        end
                        count = count + 1;
                    else
                        if IsBC_new(flag) ~= 0
                            BoundEdges(IsBC_new(flag),:) = [];
                            BoundEdges(IsBC_new(flag),:) = [];
                            BoundExtNormal(IsBC_new(flag),:) = [];
                            BoundExtNormal(IsBC_new(flag),:) = [];
                            IsBC_new(flag) = 0;
                            EdgeCount = EdgeCount - 2;
                        end
                        iglob(iloc) = flag;
                    end
                end %iloc
                %----------------------------------------------------------
                % update triang_v
                id = (4*(iel-1))*ones(1,4) + (1:4);
                triang_v(id(1),:) = [verteces(1), iglob(1), iglob(3)];
                triang_v(id(2),:) = [verteces(2), iglob(2), iglob(1)];
                triang_v(id(3),:) = [verteces(3), iglob(3), iglob(2)];
                triang_v(id(4),:) = [iglob(1)   , iglob(2), iglob(3)];
                % update connectivity
                this.connectivity(iel,:) = id;
                %----------------------------------------------------------
            end 
            coord_v = coord_v(1:count-1,:);
            this.Bound.EdgesLength = zeros(size(BoundEdges,1),1);
            for iedge = 1 : size(BoundEdges,1)
                iglob = BoundEdges(iedge,1);
                jglob = BoundEdges(iedge,2);
                this.Bound.EdgesLength(iedge) = norm(coord_v(iglob,:) - coord_v(jglob,:));
            end
            %--------------------------------------------------------------
            % set domain info
            this.X_limits = [min(coord(:,1)),max(coord(:,1))];
            this.Y_limits = [min(coord(:,2)),max(coord(:,2))];
            this.Bound.Nodes     = BoundNodes;
            this.Bound.Edges     = BoundEdges;
            this.Bound.ExtNormal = BoundExtNormal;
            this.Bound.Check(1:size(coord_v,1)) = "none";
            this.Bound.BCid  = sparse(zeros(size(coord_v,1),1));
            %--------------------------------------------------------------
            % set P
            this.P.triang = triang;
            this.P.coord  = coord;
            this.P.Nodes  = Nodes_p;
            this.P.Nelem  = Nelem_p; 
            %--------------
            % set V
            this.V.coord  = coord_v;
            this.V.triang = triang_v; 
            this.V.Nelem  = size(this.V.triang,1);
            this.V.Nodes  = size(this.V.coord,1);
            this.V.DirNod = [];
            this.V.DirVal = [];
            this.V.NDir   = [];
            
            this.V.NeuNod = [];
            this.V.NeuVal = [];
            this.V.NNeu   = [];
            %--------------------------------------------------------------
            %%% set coefficients    
            this.mu  = mu;
            this.f_1 = f_1; 
            this.f_2 = f_2; 
            this.g   = g;
            %--------------------------------------------------------------
            if flag_mesh
                trimesh(this.V.triang,this.V.coord(:,1),this.V.coord(:,2),'Color','k')
                hold on 
                trimesh(this.P.triang,this.P.coord(:,1),this.P.coord(:,2),'Color','r','LineWidth',1.1)
                legend('Vocity mesh', 'Pressure mesh');
            end
            %--------------------------------------------------------------
            % Upper wall
            this = this.setDirBC(1, [this.X_limits(1);this.X_limits(2)],1,[0;0]);
            % Lower wall
            this = this.setDirBC(1, [this.X_limits(1);this.X_limits(2)],0,[0;0]);
            % Left wall
            this = this.setDirBC(2, [this.Y_limits(1);this.Y_limits(2)],0,[0;0]);
            % Right wall
            this = this.setDirBC(2, [this.Y_limits(1);this.Y_limits(2)],1,[0;0]);
        end
        %------------------------------------------------------------------
        %%% PREPRO
        %------------------------------------------------------------------
        function this = prepro(this)
            %----------
            this = prepro@Stokes(this);
            %----------
            % Compute Matrices
            [M ,  A] = BuildMass_Diff(this);
            [B1, B2] = Build_b(this);
            [rhs, P_bc] = forcing(this);
            this.LinSys.M      = M;
            this.LinSys.A      = A;
            this.LinSys.B1     = B1;
            this.LinSys.B2     = B2;
            this.LinSys.rhs    = rhs;
            this.LinSys.P_bc   = P_bc;
        end
        %------------------------------------------------------------------
    end
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    % PRIVATE METHODS
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    methods( Access = private)
        %------------------------------------------------------------------
        %% MATRIX CONSTRUCTION
        %%% MASS MATRIX
        function [M, A] = BuildMass_Diff(this)
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            H_val    = zeros(Nelem_v*9,1);
            M_val    = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=triang_v(iel,iloc);
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=triang_v(iel,jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        H_val(it)=(Bloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                   Cloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                        %--------------------------------------------------
                        if iloc==jloc
                             M_val(it)=Area_v(iel)/6;
                         else
                             M_val(it)=Area_v(iel)/12;
                        end
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            % BUILD MATRICES
            A = sparse(i_sparse,j_sparse,H_val);
            M = this.rho*sparse(i_sparse,j_sparse,M_val);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD BILINEAR FORM b(v,q)
        %------------------------------------------------------------------
        function [B1, B2] = Build_b(this)
            %--------------------------------------------------------------
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            B1_val   = zeros(36*this.P.Nelem,1);
            B2_val   = zeros(36*this.P.Nelem,1);
            % 
            i_p      = zeros(36*this.P.Nelem,1);
            k_p      = zeros(36*this.P.Nelem,1);
            % 
            %--------------------------------------------------------------
            % Build B1 and B2
            it = 1;
            for kel = 1 : this.P.Nelem
                triNB = this.connectivity(kel,:);
                for kloc = 1:3
                    kglob = this.P.triang(kel,kloc);
                    for iel_loc = 1 : 4
                        iel = triNB(iel_loc);
                        for iloc = 1 : 3
                            iglob = triang_v(iel,iloc);
                            B1 = 0;
                            B2 = 0;
                            %----------------------------------------------
                            if kloc == iel_loc
                                % first sum
                                B1=B1+Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+Cloc_v(iel,iloc)*Area_v(iel)/3;
                            end
                            %----------------------------------------------
                            if kloc == iel_loc || iel_loc == 4
                                % double second sum
                                B1=B1+0.5*2*Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+0.5*2*Cloc_v(iel,iloc)*Area_v(iel)/3;
                            else 
                                % just one second sum
                                B1=B1+0.5*Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+0.5*Cloc_v(iel,iloc)*Area_v(iel)/3;
                            end
                            %----------------------------------------------
                            % update
                            i_p(it)=iglob;
                            k_p(it)=kglob;
                            B1_val(it)=-B1;
                            B2_val(it)=-B2;
                            it=it+1;
                        end
                    end
                end
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            B1=sparse(k_p,i_p,B1_val);
            B2=sparse(k_p,i_p,B2_val);
            %--------------------------------------------------------------
        end
    end
end