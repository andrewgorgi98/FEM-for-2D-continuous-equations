classdef Solver
    % Solver class
    % Contains all the general methods for an object of type solver
    
    properties
        X_limits = zeros(2,1);
        Y_limits = zeros(2,1);
        V;
        P;
        Bound;
        LinSys;
    end
    
    methods (Access = public)
        %------------------------------------------------------------------
        function this = copy(this, solver)
            this.X_limits         = solver.X_limits;
            this.Y_limits         = solver.Y_limits;
            this.V                = solver.V;
            this.P                = solver.P;
            this.Bound            = solver.Bound;
            this.LinSys           = solver.LinSys;
        end
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir, flag_mesh)
            % Construct an instance of this class
            %   Detailed explanation goes here
            % meshdir: name of the folder which contains the mesh
            % nfig: number of the first free figure panel
            
%             mesh=[];
            meshtriang   = strcat(meshdir, '/mesh.dat');
            meshcoord    = strcat(meshdir, '/xy.dat');
            meshBoundNod = strcat(meshdir, '/dirtot.dat');
            %--------------------------------------------------------------
            load(meshtriang  , 'mesh'  );
            load(meshcoord   , 'xy'    );
            load(meshBoundNod, 'dirtot');
            BoundNodes = dirtot(:,1);
            %--------------------------------------------------------------
            triang = mesh(:,1:3);
            coord  = xy;
            Nelem_p  = length(triang(:,1));
            %--------------------------------------------------------------
            %%% find boundary edges (for Neumann BCs)
            BoundEdges                = zeros(length(BoundNodes),2);
            BoundExtNormal            = zeros(length(BoundEdges),2);
            EdgeCount                 = 0;
            IsBC      = zeros(size(coord,1),1);
            
            IsBC(BoundNodes) = 1;
            
            for iel=1:Nelem_p
                verteces = triang(iel,:);
                for iloc=1:3
                    iarc = verteces(iloc); jarc = verteces(mod_n(iloc+1,3));
                    if IsBC(iarc) && IsBC(jarc)
                        %----------------------------------------------
                        EdgeCount = EdgeCount + 1;
                        BoundEdges(EdgeCount,:) = [iarc, jarc];  
                        %--------------------------------------
                        thirdNode = verteces(mod_n(iloc + 2,3));
                        normal    = this.extNormal(coord(iarc,:), coord(jarc,:), coord(thirdNode,:));
                        BoundExtNormal(EdgeCount,:)  = normal;
                        %----------------------------------------------
                    end
                end %iloc
                %----------------------------------------------------------
            end 
            this.Bound.EdgesLength = zeros(size(BoundEdges,1),1);
            for iedge = 1 : size(BoundEdges,1)
                iglob = BoundEdges(iedge,1);
                jglob = BoundEdges(iedge,2);
                this.Bound.EdgesLength(iedge) = norm(coord(iglob,:) - coord(jglob,:));
            end
            %--------------------------------------------------------------
            % set domain info
            this.X_limits = [min(coord(:,1)),max(coord(:,1))];
            this.Y_limits = [min(coord(:,2)),max(coord(:,2))];
            this.Bound.Nodes = BoundNodes;
            this.Bound.Edges = BoundEdges;
            this.Bound.ExtNormal = BoundExtNormal;
            this.Bound.Check(1:size(coord,1)) = "none";
            this.Bound.BCid  = sparse(zeros(size(coord,1),1));
            %--------------------------------------------------------------
            this.P.triang = triang;
            this.P.coord  = coord;
            this.P.Nodes  = size(coord,1);
            this.P.Nelem  = Nelem_p; 
            %--------------
            this.V.triang = triang;
            this.V.coord  = coord;
            this.V.Nelem  = Nelem_p;
            this.V.Nodes  = this.P.Nodes;
            this.V.DirNod = [];
            this.V.DirVal = [];
            this.V.NDir   = [];
            
            this.V.NeuNod = [];
            this.V.NeuVal = [];
            this.V.NNeu   = [];
            %--------------------------------------------------------------
            if flag_mesh
                trimesh(this.V.triang,this.V.coord(:,1),this.V.coord(:,2),'Color','k')
            end
            %--------------------------------------------------------------
            % Upper wall
            this = this.setDirBC(1, [this.X_limits(1);this.X_limits(2)],1,[0;0]);
            % Lower wall
            this = this.setDirBC(1, [this.X_limits(1);this.X_limits(2)],0,[0;0]);
            % Left wall
            this = this.setDirBC(2, [this.Y_limits(1);this.Y_limits(2)],0,[0;0]);
            % Right wall
            this = this.setDirBC(2, [this.Y_limits(1);this.Y_limits(2)],1,[0;0]);
        end
        %------------------------------------------------------------------
        %% FIND BOUNDARY ELEMENTS
        %------------------------------------------------------------------
        % to create a .dat file with the boundary elements (triangles) and 
        % edges
        function [] = findBoundary(this,path)
            triang      = this.P.triang;
            coord       = this.P.coord;
            BoundNod    = zeros(this.P.Nodes,1);
            BoundEdge   = zeros(this.P.Nelem,2);            
            %-----------------------------------
            %FIND NODES
            count = 1;
            for iglob = 1 : this.P.Nodes
                x = coord(iglob,1); y = coord(iglob,2);
                if isBoundary(this,[x,y])
                    %-----------------------
                    BoundNod(count) = iglob;
                    count = count + 1;
                    %-----------------------
                end
            end
            BoundNod = BoundNod(BoundNod > 0);
            %-----------------------------------
            % FIND EDGES
            count = 1;
            for iel = 1:this.P.Nelem
                for iedge = 1:3
                    edge_glob = [triang(iel,iedge),triang(iel,mod_n(iedge+1,3))];
                    if all(isBoundary(this,coord(edge_glob,:)))
                        BoundEdge(count,:) = edge_glob;
                        count = count + 1;
                    end
                end
            end
            BoundEdge = BoundEdge(1:count-1,:);
            dlmwrite(char(path+"/"+'BoundNodes.dat'),BoundNod);
            writematrix(BoundEdge,char(path + "/" + "BoundEdges.dat"),'Delimiter','tab');
        end
        %------------------------------------------------------------------
        %%% SEE BOUNDARY NODES FROM GEOMETRY ID
        %------------------------------------------------------------------
        function []  = BoundFromId(this, id)
            plot(this.V.coord(this.Bound.Nodes(this.Bound.NodesId==id),1),...
                 this.V.coord(this.Bound.Nodes(this.Bound.NodesId==id),2), 'b*');
        end
        %% SET BC
        %------------------------------------------------------------------
        %%% DIRICHLET BC 
        %------------------------------------------------------------------
        function this = setDirBC(this, direction, range, fixcoord, value)
            %METHOD1 Summary of this method goes here
            %   direction: 1 -> x direction (upper/lower wall)
            %              2 -> y direction (left/right wall)
            %   range    : 2x1 array, range of chosen coordinates
            %   fixvalue : value of the fixed coord
            %   value    : vector or function handle
            %--------------------------------------------------------------
            BNodes = this.Bound.Nodes;
            coord = this.V.coord;
            %---------------
            switch direction
                case 1
                    limits = this.X_limits;
                case 2
                    limits = this.Y_limits;
            end
            %--------------
            if ~(ismember(fixcoord,limits))
                error('wrong coords for BC');
            end
            %----------
            for ibound = 1 : length(BNodes)
                iglob = BNodes(ibound);
                coord_node = coord(iglob,:);
                
                if (coord_node(mod_n(direction+1,2))==fixcoord   && ...
                                coord_node(direction) <= range(2) && ...
                                 coord_node(direction) >= range(1))
                     %--------
                    index = this.Bound.BCid(iglob);
                    switch this.Bound.Check(iglob)
                        case "Neu"
                            this = DeleteBC(this,"Neu",index);
                            this.Bound.Check(iglob) = "Dir";
                            this.V.DirNod = [this.V.DirNod, iglob];
                            index = length(this.V.DirNod);
                            this.Bound.BCid(iglob) = index;
                        case "Dir"

                        otherwise
                            this.Bound.Check(iglob) = "Dir";
                            this.V.DirNod = [this.V.DirNod, iglob];
                            index = length(this.V.DirNod);
                            this.Bound.BCid(iglob) = index;
                    end
                    if isa(value,'function_handle')
                        this.V.DirVal(index,:) = value(coord(iglob,1),coord(iglob,2));
                    else
                        this.V.DirVal(index,:) = value;
                    end
                end
            end
            %--------------------------------------------------------------   
            this.V.NDir = size(this.V.DirNod,2);
        end
        %------------------------------------------------------------------
        %%% Dirichlet BC using Geometry indices
        %------------------------------------------------------------------
        function this = setEdgeDirBC(this, bound_id, func_val)
                    %METHOD1 Summary of this method goes here
                    %   bound_id : edge index (from COMSOL) to set BC
                    %   func_val : function on the boundary to get BC values
                    %------------------------------------------------------
                    coord = this.V.coord;
                    Bedges = this.Bound.Edges; 
                    BedgesId = this.Bound.EdgesId;
                    %---------------
                    for iedge = 1 : length(Bedges)
                        if (BedgesId(iedge) == bound_id)
                            for iloc = 1:2
                                iglob = Bedges(iedge, iloc);
                                index = this.Bound.BCid(iglob);
                                switch this.Bound.Check(iglob)
                                    case "Neu"
                                        this = DeleteBC(this,"Neu",index);
                                        this.Bound.Check(iglob) = "Dir";
                                        this.V.DirNod = [this.V.DirNod, iglob];
                                        index = length(this.V.DirNod);
                                        this.Bound.BCid(iglob) = index;
                                    case "Dir"
                    
                                    otherwise
                                        this.Bound.Check(iglob) = "Dir";
                                        this.V.DirNod = [this.V.DirNod, iglob];
                                        index = length(this.V.DirNod);
                                        this.Bound.BCid(iglob) = index;
                                end
                            this.V.DirVal(index,:) = func_val(coord(iglob,1), coord(iglob,2));
                            end
                        end
                    end
                    %--------------------------------------------------------------
                    ndir = size(this.V.DirNod,2);
                    this.V.NDir = ndir;
        end
        %%%% NEUMANNN
        %------------------------------------------------------------------
        function this = setNeuBC(this, direction, range, fixcoord, flux)
            %METHOD1 Summary of this method goes here
            %   direction: 1 -> x direction (upper/lower wall)
            %              2 -> y direction (left/right wall)
            %   range    : 2x1 array, range of chosen coordinates
            %   fixvalue : value of the fixed coord
            %   flux     : flux vector
            %--------------------------------------------------------------
            BEdges  = this.Bound.Edges;
        
            %---------------
            switch direction
                case 1
                    limits = this.X_limits;
                case 2
                    limits = this.Y_limits;
            end
            %--------------
            if ~(ismember(fixcoord,limits))
                error('wrong coords for BC');
            end
            %--------------------------        
            for iedge = 1 : size(BEdges,1)
                length_edge = this.Bound.EdgesLength(iedge);
                for iloc = 1:2
                    iglob = BEdges(iedge,iloc);
                    coord_node = this.V.coord(iglob,:);
                %----------
                if (coord_node(mod_n(direction+1,2))==fixcoord   && ...
                                coord_node(direction) <= range(2) && ...
                                 coord_node(direction) >= range(1))
                     %--------
                    index = this.Bound.BCid(iglob);
                    switch this.Bound.Check(iglob)
                        case "Dir"
                            this = DeleteBC(this,"Dir",index);
                            this.Bound.Check(iglob) = "Neu";
                            this.V.NeuNod = [this.V.NeuNod, iglob];
                            index = length(this.V.NeuNod);
                            this.Bound.BCid(iglob) = index;
                            this.V.NeuVal(index,:) = flux*length_edge /2;
                        case "Neu"
                            this.V.NeuVal(index,:) = this.V.NeuVal(index,:) + flux*length_edge /2;
                        otherwise
                            this.Bound.Check(iglob) = "Neu";
                            this.V.NeuNod = [this.V.NeuNod, iglob];
                            index = length(this.V.NeuNod);
                            this.Bound.BCid(iglob) = index;
                            this.V.NeuVal(index,:) = flux*length_edge /2;
                    end
                    %-----------
                end % end if
                %----------
                end % end for iloc
                %----------
            end % end for iedge
            this.V.NNeu = size(this.V.NeuNod,2);          
        end
        %%% NEUMANN BC BY GEOMETRY INDEX
        %------------------------------------------------------------------
        function this = setEdgeNeuBC(this, bound_id, flux)
            %METHOD1 Summary of this method goes here
            %   bound_id : edge index (from COMSOL) to set BC
            %   flux     : outgoing normal flux vector
            %--------------------------------------------------------------
            Bedges = this.Bound.Edges; 
            BedgesId = this.Bound.EdgesId;
        
            for iedge = 1 : length(Bedges)
                if (BedgesId(iedge) == bound_id)
                    length_edge = this.Bound.EdgesLength(iedge);
                    %----------
                    for iloc = 1:2
                        iglob = Bedges(iedge,iloc);
                        index = this.Bound.BCid(iglob);
                        %----------
                        switch this.Bound.Check(iglob)
                            case "Dir"
                                this = DeleteBC(this,"Dir",index);
                                this.Bound.Check(iglob) = "Neu";
                                this.V.NeuNod = [this.V.NeuNod, iglob];
                                index = length(this.V.NeuNod);
                                this.Bound.BCid(iglob) = index;
                                this.V.NeuVal(index,:) = flux*length_edge /2;
                            case "Neu"
                                this.V.NeuVal(index,:) = this.V.NeuVal(index,:) + flux*length_edge /2;
                            otherwise
                                this.Bound.Check(iglob) = "Neu";
                                this.V.NeuNod = [this.V.NeuNod, iglob];
                                index = length(this.V.NeuNod);
                                this.Bound.BCid(iglob) = index;
                                this.V.NeuVal(index,:) = flux*length_edge /2;
                        end
                        %-----------
                    end % end for iloc
                    %----------
                end % end if
                %----------
            end % end for iedge
            this.V.NNeu = size(this.V.NeuNod,2);
                    
        end
        function this = clearBC(this)
            this.V.DirNod = [];
            this.V.DirVal = [];
            this.V.Ndir   = 0 ;
            this.Bound.Check(:) = "none";
            this.V.NeuNod = [];
            this.V.NeuVal = [];
            this.V.NNeu   = 0 ;
        end
        %------------------------------------------------------------------
        %% INIT CONDITION
        %------------------------------------------------------------------
        function [u1_0, u2_0] = zeroInitCond(this)
            Nodes = this.V.Nodes;
            u1_0 = zeros(Nodes,1);
            u2_0 = zeros(Nodes,1);
        end
        %------------------------------------------------------------------
        %% OUTPUT
        function nfig = PrintRes(this, uh1, uh2, p, nfig)
            Nodes_p = this.P.Nodes;
            Print(this,this.P.triang, this.P.coord, uh1(1:Nodes_p), nfig);
            axis([this.X_limits, this.Y_limits]);
            nfig = nfig + 1;
            Print(this,this.P.triang, this.P.coord, uh2(1:Nodes_p), nfig);
            axis([this.X_limits, this.Y_limits]);
            nfig = nfig + 1;
            Print(this,this.P.triang, this.P.coord, p, nfig);
            nfig = nfig + 1;
        end
        function nfig = PrintResIso(this, uh1, uh2, p, nfig)
            IsoPrint(this, this.V.coord, uh1, nfig);
            axis([this.X_limits, this.Y_limits]);
            nfig = nfig + 1;
            IsoPrint(this,this.V.coord, uh2, nfig);
            axis([this.X_limits, this.Y_limits]);
            nfig = nfig + 1;
            IsoPrint(this, this.P.coord, p, nfig);
            nfig = nfig + 1;
        end
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        function [] = Print(~,triang, coord, sol, nfig)
            figure(nfig)
            triplot(triang,coord(:,1),coord(:,2),'k');
            % triplot(triang,coord(:,1),coord(:,2));
            triplot(triang,coord(:,1),sol,'c');
            trisurf(triang,coord(:,1),coord(:,2),sol);%, 'LineStyle', 'none');%,'FaceColor','none')
        end
        %------------------------------------------------------------------
        function [] = IsoPrint(~,coord, sol, nfig)
            cd triplot
            figure(nfig)
            cMap=jet(256);
            x=coord(:,1); y=coord(:,2);
            M=delaunay(x,y);
            tricontf(x,y,M,sol,10);
            colormap(cMap);
            colorbar;
            axis equal;
            cd ..
        end
        %------------------------------------------------------------------
        %% GET SOLUTION IN GENERAL POINT OF THE DOMAIN (FAST)
        %------------------------------------------------------------------
        function [u1,u2] = getApproxValue_v(this,point,uh1,uh2)
            coord = this.V.coord;
            toll = 1e-3;
            dist = max(this.X_limits(2),this.Y_limits(2));
            for iglob = 1 : size(coord,1)
                temp_dist = norm(point-coord(iglob,:)');
                if temp_dist < dist
                    dist = temp_dist;
                    u1 = uh1(iglob); u2 = uh2(iglob);
                end
                if (dist < toll)
                    break;
                end
            end
        end
        %------------------------------------------------------------------
        %% GET SOLUTION IN GENERAL POINT OF THE DOMAIN (ACCURATE)
        %------------------------------------------------------------------
        function [u1,u2,lambda_v] = getValue_v(this,point,uh1,uh2)
            triang_v = this.V.triang;
            coord_v  = this.V.coord;
            lambda_v   = zeros(3,1);
            flag = 0;
            for iel = 1:this.V.Nelem
                Nodes_v = [triang_v(iel,1), triang_v(iel,2), triang_v(iel,3)];
                P1 = coord_v(Nodes_v(1),:)';
                P2 = coord_v(Nodes_v(2),:)';
                P3 = coord_v(Nodes_v(3),:)';
                A  = [(P2-P1), (P3-P1)];
                b  = point - P1;
                lambda_v(2:3) = A\b;
                lambda_v(1)   = 1 - lambda_v(2) - lambda_v(3);
                if all(lambda_v>=0) && all(lambda_v<= 1)
                    flag = 1;
                    break;
                end
            end
            if flag 
                u1 = lambda_v'*uh1(Nodes_v); 
                u2 = lambda_v'*uh2(Nodes_v);
            else
                u1 = 0;
                u2 = 0;
            end
        end
        %-----------------------
        function p = getValue_p(this,point,ph)
            triang_p = this.P.triang;
            coord_p  = this.P.coord;
            lambda_p   = zeros(3,1);
            for iel = 1:this.P.Nelem
                Nodes_p = [triang_p(iel,1), triang_p(iel,2), triang_p(iel,3)];
                P1 = coord_p(Nodes_p(1),:)';
                P2 = coord_p(Nodes_p(2),:)';
                P3 = coord_p(Nodes_p(3),:)';
                A  = [P2-P1, P3-P1];
                b  = point - P1;
                lambda_p(2:3) = A\b;
                lambda_p(1)   = 1 - lambda_p(2) - lambda_p(3);
                if all(lambda_p>=0) && all(lambda_p<= 1)
                    break;
                end
            end
            p = lambda_p'*ph(Nodes_p);
        end
    end
    %----------------------------------------------------------------------
    %% PROTECTED METHODS
    %----------------------------------------------------------------------
    methods (Access = protected)
        
    end
    %----------------------------------------------------------------------
    %% PRIVATE METHODS
    %----------------------------------------------------------------------
    methods (Access = private)
        function flag = isBoundary(this, coord)
            x = coord(1); y = coord(2);
            X_lim = this.X_limits; Y_lim = this.Y_limits;
            flag = (ismember(x,X_lim) && (Y_lim(1) <= y) && (y <= Y_lim(2))) ||...
                    (ismember(y,Y_lim) && (X_lim(1) <= x) && (x <= X_lim(2)));
        end
        function this = DeleteBC(this, BCname,index)
            switch BCname
                case "Dir"
                    this.V.DirNod(index) = [];
                    this.V.DirVal(index,:) = [];
                    this.V.NDir = this.V.NDir-1;
                    for i = index:this.V.NDir
                        ibound = this.V.DirNod(i);
                        this.Bound.BCid(ibound) = this.Bound.BCid(ibound)-1;
                    end
                case "Neu"
                    this.V.NeuNod(index) = [];
                    this.V.NeuVal(index,:) = [];
                    this.V.NNeu = this.V.NNeu-1;
                    for i = index:this.V.NNeu
                        ibound = this.V.NeuNod(i);
                        this.Bound.BCid(ibound) = this.Bound.BCid(ibound)-1;
                    end
            end
        end
    end
    %----------------------------------------------------------------------
    %% STATIC METHODS
    %----------------------------------------------------------------------
    methods (Static)
        %------------------------------------------------------------------
        % FIND EDGE EXTERNAL NORMAL
        %------------------------------------------------------------------
        function extNormal = extNormal(p1, p2, third)
            %-------
            perp   = zeros(2,1);
            extNormal = zeros(1,2);
            %-------
            perp(1)  = p1(2) - p2(2);
            perp(2)  = p2(1) - p1(1);
            midPoint = (p1 + p2)./2;
            vect     = third - midPoint;
            %-------
            if vect*perp > 0
                extNormal(1,:) = -perp./(norm(perp));
            else
                extNormal(1,:) = perp./(norm(perp));
            end
            %------------------------------------------
        end
        %------------------------------------------------------------------
        % BUILD LOCAL FUNCTIONS
        %------------------------------------------------------------------
        function [Bloc, Cloc, Area] = LocalBasis(Nelem,triang,coord)
            %--------------------------------------------------------------
            % build local P1 basis functions on triangles 
            % only the coefficients (b,c) multiplying x and y are built
            % \phi(x,y) = a + b x + c y
            %  b_i=y_j-y_k  (i->j->k->i)
            %  c_i=x_k-x_j  (i->j->k->i)
            %--------------------------------------------------------------
            Bloc=zeros(Nelem,3);
            Cloc=zeros(Nelem,3);
            Area=zeros(Nelem,1);
            %--------------------------------------------------------------
            for iel=1:Nelem
                nodes=triang(iel,:);
                p1=coord(nodes(1),:);
                p2=coord(nodes(2),:);
                p3=coord(nodes(3),:);
                A=[1 p1 ; 1 p2 ; 1 p3];
                DetA=det(A);
                Area(iel)=abs(DetA)/2;
                %----------------------------------------------------------
                for inod=1:3
                    n1=mod_n(inod+1,3);
                    n2=mod_n(inod+2,3);
                    Bloc(iel,inod)=(coord(nodes(n1),2)-coord(nodes(n2),2))/DetA;
                    Cloc(iel,inod)=(coord(nodes(n2),1)-coord(nodes(n1),1))/DetA;
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
        end
         %------------------------------------------------------------------
        %% ERROR EVALUATION
        %------------------------------------------------------------------
       function err=evalErr(fh, freal, meshStruct)
            %----------------
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %---------------
            Area  = meshStruct.Area;
            triang = meshStruct.triang;
            err=0;
            %------
            if isa(freal,'function_handle')
                coord = meshStruct.coord;
                for iel=1:meshStruct.Nelem
                    for iloc=1:3
                        iglob=triang(iel,iloc);
                        err=err+...
                            (fh(iglob)-freal(coord(iglob,1),coord(iglob,2)))^2*Area(iel)/3;
                    end
                end
            else
                for iel=1:meshStruct.Nelem
                    for iloc=1:3
                        iglob=triang(iel,iloc);
                        err=err+...
                            (fh(iglob)-freal(iglob))^2*Area(iel)/3;
                    end
                end
            end
            %-----
            err=sqrt(err);
            %-------------
        end
        %------------------------------------------------------------------
        % READ DATA
        %------------------------------------------------------------------
        function [coord, triang, bound_edges, bound_edges_id] = readFromComsolMesh(meshdir)
            %--------------------------------------------------------------
            cellData = readcell(meshdir);
            nNodes = cellData{15,1};            
            nEdges = cellData{15+2+nNodes+5,1};            
            nEdgesId = cellData{15+3+nNodes+5+nEdges+1,1};            
            nEl = cellData{15+3+nNodes+5+1+nEdges+1+nEdgesId + 4,1};            
            count = 17;            
            coord= zeros(nNodes,2);
            for i=1:nNodes
                count =count+1;
                for j=1:2
                    coord(i,j) = cellData{count,j};
                end
            end            
            count=count+6;            
            bound_edges = zeros(nEdges,2);
            for i=1:nEdges
                count = count+1;
                for j=1:2
                    bound_edges(i,j) = cellData{count,j}+1;
                end
            end            
            count = count + 2;            
            bound_edges_id = zeros(nEdgesId,1);
            for i=1:nEdgesId
                count = count+1;
                bound_edges_id(i) = cellData{count,1}+1;
            end            
            count = count + 5;            
            triang = zeros(nEl,3);
            for i=1:nEl
                count = count+1;
                for j=1:3
                    triang(i,j) = cellData{count,j}+1;
                end
            end
            %--------------------------------------------------------------
        end
        %--------------------------------------------------------------
        function [problem, meshdir, NStokes, nfig, rho, mu, f_1, f_2, g, nInletId, inlet_id, nOutletId, outlet_id, flag, ...
                  flag_BC, V_r, V_0, c, tau, flag_functional, alpha_min, alpha_max, q, terminationMethod, maxIt, toll,u_in] = NStokesParameters()
            %------------------------------------------------
            % INITIALIZE PARAMETERS WITH LAST USED ONES
            %------------------------------------------------
            previousParameters = readcell('previousProject.txt');
            % Define the 2D mesh and equation BC's and coefficients
            problem = previousParameters{1};
            meshdir = previousParameters{2};
            nfig    = previousParameters{3};
            %--------------------------------------------------------------------------
            % SET PARAMETERS
            %--------------------------------------------------------------------------
            flag      = previousParameters{4}; % flag=1 to see the mesh
            mu        = previousParameters{5};
            rho       = previousParameters{6};
            c         = previousParameters{7};
            f_1       = str2func(previousParameters{8});
            f_2       = str2func(previousParameters{9});
            g         = str2func(previousParameters{10});
            tau       = previousParameters{11};
            nInletId  = previousParameters{12};
            inlet_id  = zeros(nInletId,1);
            for i = 1:nInletId
            inlet_id(i)  = previousParameters{13,i};
            end
            nOutletId  = previousParameters{14};
            outlet_id = zeros(nOutletId,1);
            for j = 1:nOutletId
            outlet_id(j)  = previousParameters{15,j};
            end
%             inlet_id  = previousParameters{12};
%             outlet_id = previousParameters{13};
            V_r       = previousParameters{16};
            V_0       = previousParameters{17};  %%% !!!!!!!!!!!! TO BE SET WITH GEOMETRY !!!!!!!!
            flag_BC   = previousParameters{18}; % BC: 0 for FAST penalty method
                                                %   : 1 for ACCURATE lifting function method
            %------------------------------------------------
            % IMPOSE OTHER PARAMETERS
            %------------------------------------------------
            % flag_functional = 1 for min (\alpha ||u||^2)
            %                   2 for min (\alpha ||u||^2 + \ni ||grad(u)||^2)
            %                   3 for min (\ni * ||grad(u)||^2)
            %                   4 for max (u^2/2 + p/\rho)
            %                   5 for min (||u||^2*dirac_delta(x-x*))
            %                   6 for max (||u||^2*dirac_delta(x-x*))
            %-------------------
            flag_functional = previousParameters{19};
            alpha_min       = previousParameters{20};
            alpha_max       = previousParameters{21};
            q               = previousParameters{22};
            %------------------------------------------------
            % TERMINATION METHOD
            %------------------------------------------------
            terminationMethod = previousParameters{23};
            maxIt             = previousParameters{24};
            toll              = previousParameters{25};
            %------------------------------------------------
            % INLET VELOCITY FUNCTION
            %------------------------------------------------
            u_in = str2func(previousParameters{26});
            %------------------------------------------------
            % CREATE A PROJECT WITH LAST USED PARAMETERS
            %------------------------------------------------
            NStokes = RevisedNavierStokes(meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag);
            %------------------------------------------------
            %% MODEL BUILDER
            %------------------------------------------------
            somethingNew = input('Press ENTER to launch the last project, or insert 1 to enter the MODEL BUILDER: ');
            if somethingNew == 1
                disp('-----------------------------------');
                disp('MODEL BUILDER')
                disp('-----------------------------------');
                option = input(['||Legend|| \n' ...
                                '(1) CHANGE PROJECT \n' ...
                                '(2) SET BOUNDARY EDGES \n' ...
                                '(3) CHANGE MODEL PARAMETERS \n' ...
                                '(4) CHANGE TOPOLOGY OPTIMIZATION PARAMETERS \n' ...
                                '(5) CHANGE TERMINATION METHOD \n' ...
                                'Selection: ']);
                if option == 1
                    problem = input('Insert the new problem "name": ', 's');
                    meshdir=strcat('mesh_COMSOL\', problem, '\', problem, '.txt');
                    V_0    = input('Insert the new problem "volume": ');
                    V_r    = input('Insert the new problem "fractional optimization volume": ');
                    %------------------------------------------------
                    % APPLY THE NEW MESH
                    %------------------------------------------------
                    NStokes = RevisedNavierStokes(meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag);
                    option = input(['||Legend|| \n' ...
                                    '(2) SET BOUNDARY EDGES \n' ...
                                    '(3) CHANGE MODEL PARAMETERS \n' ...
                                    '(4) CHANGE TOPOLOGY OPTIMIZATION PARAMETERS \n' ...
                                    '(5) CHANGE TERMINATION METHOD \n' ...
                                    'PRESS ENTER TO START THE SOLUTION \n' ...
                                    'Selection: ']);
                end
                if option == 2
                    %------------------------------------------------
                    %% PLOT BOUNDARY EDGES ID
                    %------------------------------------------------
                    figure(1)
                    hold on;
                    % TESTING PLOT SIDES
                    PlotSideNodes(NStokes.X_limits, NStokes.Y_limits, NStokes.V.coord, ...
                        NStokes.Bound.Nodes, NStokes.Bound.NodesId, 1:max(NStokes.Bound.EdgesId));
                    drawnow;
                    hold off;

                    nInletId  = input('Insert the new "number of inlets" : ');
                    inlet_id  = input('Insert the new INLET ID : ');
                    nOutletId = input('Insert the new "number of outlets" : ');                    
                    outlet_id = input('Insert the new OUTLET ID : ');
                    u_in      = input('Insert the new Inlet function : ');
                    option = input(['||Legend|| \n' ...
                                    '(3) CHANGE MODEL PARAMETERS \n' ...
                                    '(4) CHANGE TOPOLOGY OPTIMIZATION PARAMETERS \n' ...
                                    '(5) CHANGE TERMINATION METHOD \n' ...
                                    'PRESS ENTER TO START THE SOLUTION \n' ...
                                    'Selection: ']);
                end
                if option == 3
                    %--------------------------------------------------------------------------
                    % SET NEW PARAMETERS
                    %--------------------------------------------------------------------------
                    flag      = input('Insert the new "flag": '); % flag=1 to see the mesh
                    mu        = input('Insert the new "mu": ');
                    rho       = input('Insert the new "rho": ');
                    c         = input('Insert the new "c": ');
                    f_1       = str2func(input('Insert the new "f_1": ', 's'));
                    f_2       = str2func(input('Insert the new "f_2": ', 's'));
                    g         = str2func(input('Insert the new "g": ', 's'));
                    tau       = input('Insert the new "tau": ');
                    flag_BC   = input('Insert the new "flag_BC": ');
                    option = input(['||Legend|| \n' ...
                                    '(4) CHANGE TOPOLOGY OPTIMIZATION PARAMETERS \n' ...
                                    '(5) CHANGE TERMINATION METHOD \n' ...
                                    'PRESS ENTER TO START THE SOLUTION \n' ...
                                    'Selection: ']);
                end
                if option == 4
                    flag_functional = input('Insert the new "flag_functional": ');
                    alpha_min       = input('Insert the new "alpha_min": ');
                    alpha_max       = input('Insert the new "alpha_max": ');
                    q               = input('Insert the new "q": ');
                end
                if option == 5                    
                    maxIt = input('Insert the new "maxIt": ');
                    toll = input('Insert the new "toll": ');
                    terminationMethod = input('Insert the new "termination method": ', 's');
                end
            end

            %------------------------------------------------
            %% CREATE CURRENT PARAMETERS FILE
            %------------------------------------------------
            previousProjectName = 'previousProject.txt';
            previousProject = fopen(previousProjectName, 'w');
            fprintf(previousProject, '%s \n%s \n%d \n%d \n%f \n%f \n%f \n%s \n%s \n%s \n%f \n%d \n%s \n%d \n%s \n%f \n%f \n%d \n%d \n%f \n%f \n%f \n%s \n%d \n%f \n%s', ...
                    problem, meshdir, nfig, flag, mu, rho, c, func2str(f_1), func2str(f_2), func2str(g), ...
                    tau, nInletId, Solver.vect2str(inlet_id), nOutletId, Solver.vect2str(outlet_id), V_r, V_0, ...
                    flag_BC, flag_functional, alpha_min, alpha_max, q, terminationMethod, maxIt, toll, func2str(u_in));
            fclose(previousProject);

            %------------------------------------------------
            %% CREATE THE PROJECT TO EXECUTE
            %------------------------------------------------
            NStokes = RevisedNavierStokes(meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag);
            %------------------------------------------------
        end
        %------------------------------------------------
        %% TRANSOFRM VECTORS TO A STRING
        function str = vect2str(v)
            strV = string(v); 
            str = strV(1);
            for i = 2:length(strV)
                str = strcat(str, " ", strV(i));
            end
        end
    %----------------------------------------------------------------------
    %% CREATE UNIFORM MESH
    %----------------------------------------------------------------------
    function UniformMesh(Xlimits,Ylimits,N)
        x0 = Xlimits(1); x1 = Xlimits(2);
        y0 = Ylimits(1); y1 = Ylimits(2);
        %------------
        % BUILD MESH
        [x,y] = meshgrid(linspace(x0,x1,N),linspace(y0,y1,N));
        T=delaunay(x,y);
        mesh=T;
        xy=[reshape(x,[],1),reshape(y,[],1)];
        dirtot = find(xy(:,1)== x0 | xy(:,1)==x1 | ...
                      xy(:,2)== y0 | xy(:,2)==y1);
        meshdir = char("meshN/mesh"+ num2str(N) + "/mesh.dat");
        dlmwrite(meshdir, mesh);
        meshdir = char("meshN/mesh"+ num2str(N) + "/xy.dat");
        dlmwrite(meshdir, xy);
        meshdir = char("meshN/mesh"+ num2str(N) + "/dirtot.dat");
        dlmwrite(meshdir, dirtot);
    end
    end
end