%% IMPOSE BOUNDARY CONDITIONS
function [sysMat,rhs] = imposeBC(Nodes,NDir,DirNod,DirVal,sysMat,flag)
    %--------------------------------------------------------------
    % impose Dirichle BCs
    % flag: 0 => penalty method;
    %     : 1 => Lifting function;
    if nargin < 6
        flag = 0;
    end
    rhs = zeros(Nodes,1);
    %-----------------------
    %%% DIRICHLET
    %--------------------------------------------------------------
    switch flag 
        %----------------------------------------------------------
        case 0
            %------------------------------------------------------
            penalty = 1e12;
            for idir = 1:NDir
                %----------------------------------------------
                iglob               = DirNod(idir);
                sysMat(iglob,iglob) = penalty;
                rhs(iglob)          = penalty*DirVal(idir);
                %----------------------------------------------
            end
            %------------------------------------------------------
        case 1
            %------------------------------------------------------
            for idir=1:NDir
                %----------------------------------------------
                iglob           = DirNod(idir);   
                sysMat(iglob,:) = 0; 
                rhs             = rhs-DirVal(idir)*sysMat(:,iglob); 
                rhs(iglob)      = DirVal(idir);
                sysMat(:,iglob) = 0;
                sysMat(iglob,iglob) = 1;
                %----------------------------------------------
            end
            %------------------------------------------------------
    end
end
%------------------------------------------------------------------