function [Bloc,Cloc,Area]=localBasis(Nelem,triang,coord)

% build local P1 basis functions on triangles 
% only the coefficients (b,c) multiplying x and y are built
% \phi(x,y) = a + b x + c y
%  b_i=y_j-y_k  (i->j->k->i)
%  c_i=x_k-x_j  (i->j->k->i)

Bloc=zeros(Nelem,3);
Cloc=zeros(Nelem,3);
Area=zeros(Nelem,1);

for iel=1:Nelem
    nodes=triang(iel,:);
    p1=coord(nodes(1),:);
    p2=coord(nodes(2),:);
    p3=coord(nodes(3),:);
    A=[1 p1 ; 1 p2 ; 1 p3];
    DetA=det(A);
    Area(iel)=abs(DetA)/2;
    for inod=1:3
        n1=mod_n(inod+1,3);
        n2=mod_n(inod+2,3);
        Bloc(iel,inod)=(coord(nodes(n1),2)-coord(nodes(n2),2))/DetA;
        Cloc(iel,inod)=(coord(nodes(n2),1)-coord(nodes(n1),1))/DetA;
    end
end

end