function [SYSMAT,H]=stiffBuild(Nelem,Nodes,triang,Bloc,Cloc,Area,Diff,Vel,h,tau)
% build system matrix (H+B+S)
%--------------------------------------------------------------------------
%%% INITIALIZE THE SPARSE VECTORS
%--------------------------------------------------------------------------
i_sparse = zeros(Nodes*9,1);
j_sparse = zeros(Nodes*9,1);
val_B    = zeros(Nodes*9,1);
val_H    = zeros(Nodes*9,1);it=1;
%--------------------------------------------------------------------------
for iel=1:Nelem % enter the triangle
    %--------------------------------------
    for iloc=1:3 %select node i of triangle
        %-------------------------------------------------
        iglob=triang(iel,iloc); %select node j of triangle
        for jloc=1:3
            %----------------------------------------------
            jglob        = triang(iel,jloc);
            i_sparse(it) = iglob;
            j_sparse(it) = jglob;
            % stiffness matrix
            val_H(it) = (Bloc(iel,iloc)*Bloc(iel,jloc)+...
                         Cloc(iel,iloc)*Cloc(iel,jloc))*Area(iel)*Diff(iel);
            % transport matrix
            val_B(it) = (Vel(1)*Bloc(iel,jloc)+Vel(2)*Cloc(iel,jloc))*Area(iel)/3;
            
            % SUPG stablization
             if norm(Vel)==0
                 S = 0;
             else
                 S = tau/Diff(iel)*h(iel)/2/sqrt(Vel(1)^2+Vel(2)^2)*(Vel(1)*Bloc(iel,iloc)+Vel(2)*...
                     Cloc(iel,iloc))*(Vel(1)*Bloc(iel,jloc)+Vel(2)*Cloc(iel,jloc))*Area(iel);
             end
             it=it+1;
             %---------------------------------------------
        end % end jloc
    end % end iloc
end % end iel
%--------------------
% BUILD SPARSE MATRICES
%--------------------
H = sparse(i_sparse,j_sparse,val_H);
B = sparse(i_sparse,j_sparse,val_B);
SYSMAT = H + B;
%--------------------------------------------------------------------------
end


