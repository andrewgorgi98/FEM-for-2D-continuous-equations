%%% Finite element code for 2D piecewise linear Galekrin 
%%% -div(Diff grad u)(x) + div(\beta u) = 0 with Dirichlet BC 
clear all; close all; clc;

%% PARAMETERS DEFINITION
%--------------------------------------------------------------------------
% Define the 2D mesh and equation BC's and coefficients
flag_mesh = 1;        % flag_mesh = 0 ---> PRESCRIBED MESH IN THE FOLDER
                      %           = 1 ---> UNIFORM MESH WITH NXN NODES
meshdir   = 'mesh';
N         = 21;
seeMesh   = true;     % to see the mesh

flagBC = 1; % flagBC = 0 ---> PENALTY METHOD
            % flagBC = 1 ---> LIFTING OPERATOR

%--------------------------------------------------------------------------
[Nelem,Nodes,triang,coord,NDir,DirNod,DirVal,h]=input_data(flag_mesh,meshdir,N,seeMesh);
%--------------------------------------------------------------------------

%-----------------------------
% physical parameters
%-----------------------------

Diff  = 0.01*ones(Nelem,1);
Vel   = [1,3];  

%------------------------------------------------
%%% \tau calibration
%------------------------------------------------\
if Diff(1)<0.093
    tau = (0.093-Diff(1))/norm(Vel)*Diff(1)/h(1);
else 
    tau = 0;
end

currfig = 1;
if seeMesh
    currfig = 2;
end
%% LINEAR SYSTEM CONSTRUCTION
% calculate element area and elemental coefficients of basis functions
% (b,c)
[Bloc,Cloc,Area] = localBasis(Nelem,triang,coord);

% build stiffness matrix (without BCs)
[SYSMAT0, H, B, S] = BuildLSys(Nelem,Nodes,triang,Bloc,Cloc,Area,Diff,Vel,h,tau);
%--------------------------------------------------------------------------
%% IMPOSE THE BCs
%--------------------------------------------------------------------------
% impose BCs
tic;
disp('-------------------------------------------');
disp('IMPOSE BC');
disp('-------------------------------------------');
[SYSMAT,rhs] = imposeBC(Nodes,NDir,DirNod,DirVal,SYSMAT0,flagBC);
toc;
%--------------------------------------------------------------------------
%% SOLVE THE LINEAR SYSTEM
%--------------------------------------------------------------------------
% GMRES
disp('-------------------------------------------');
disp('SOLVER');
disp('-------------------------------------------');
tic;
restart=10; tol=1e-14; maxit=200;
setup.type='nofill';
setup.milu='off';
[L,U]=ilu(SYSMAT,setup);
uh = gmres(SYSMAT,rhs,restart,tol,maxit,L,U);
toc;
% % PCG
% tic;
% uh = SYSMAT\rhs;
% toc;
disp('-------------------------------------------');
%--------------------------------------------------------------------------
%% PLOT RESULTS
%--------------------------------------------------------------------------
figure(currfig);
T=triangulation(triang,coord);
triplot(triang,coord(:,1),coord(:,2),'k');
triplot(triang,coord(:,1),coord(:,2));
triplot(triang,coord(:,1),uh,'c');
trisurf(triang,coord(:,1),coord(:,2),uh,'FaceColor','none');
%--------------------------------------------------------------------------
%% MASS BALANCE
%--------------------------------------------------------------------------
disp('MASS BALANCE');
% convective flux
q_C = -Vel(1) - 0.3*Vel(2);

% diffusive flux

%%% first order approx
k          = H*uh;
q_D_approx = sum(k(DirNod));
err1 = abs(q_C-q_D_approx);

%%% better approximation
k   = (H +B )*uh;
q_D = sum(k(DirNod));

err = abs(q_C-q_D);
disp('-------------------------------------------');
fprintf('Convective flux q_C = %6.4f; \nDiffusive flux q_D = %6.4f;\nMass_in-Mass_out = %6.3e\n', q_C, -q_D, err);
disp('-------------------------------------------');

Pe = max(Vel)*h(1)/Diff(1);
fprintf('\nPeclet number: %6.3f\n',Pe);


