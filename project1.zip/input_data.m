function [Nelem,Nodes,triang,coord,NDir,DirNod,DirVal,h]=...
    input_data(flag_mesh,meshdir,N, seeMesh)
%%% Collects the mesh information and define the values of the parameters.

%--------------------------------------------------------------------------
%% MESH CONSTRUCTION
%--------------------------------------------------------------------------
if flag_mesh == 0
    %----------------------------------------------------------------------
    if nargin < 2
        error('not enough inpt variables in "input_data", specify a' + ...
              'directory for the mesh');
    end
    %------------------------------------------
    meshtriang = strcat(meshdir, '/triang.dat');
    meshcoord  = strcat(meshdir, '/xy.dat');
    meshDirNod = strcat(meshdir, '/dirnod.dat');
    meshDirVal = strcat(meshdir, '/dirval.dat');
    %-----------------------------------------
    triang = [];
    load(meshtriang,'triang');
    load(meshcoord,'xy');
    load(meshDirNod,'dirnod');
    load(meshDirVal,'dirval');
    %------------------------------------------
    triang = triang(:,1:3);
    coord  = xy;
    DirNod = dirnod;
    DirVal = dirval;
%--------------------------------------------------------------------------
else
    %----------------------------------------------------------------------
    [x,y]  = meshgrid(linspace(0,1,N),linspace(0,1,N)); % uniform mesh NxN
    triang = delaunay(x,y);
    coord  = [reshape(x,[],1),reshape(y,[],1)];

    %Gamma_1
    j       = find(coord(:,1)<=0.3);
    k       = coord(j,:);
    k       = k(:,2)==0;
    gamma_1 =[find(coord(:,1)==0);j(k)];
    
    %Gamma_2
    j       = find(coord(:,1)>0.3);
    k       = coord(coord(:,1)>0.3,:);
    k       = k(:,2)==0;
    p       = coord(coord(:,2)==1,:);
    l       = find(coord(:,2)==1);
    p       = p(:,1)~=0;
    gamma_2 = [find(coord(:,1)==1);j(k);l(p)];
    %-----------------------------------------
    DirNod  = [gamma_1;gamma_2];
    DirVal  = [ones(1,length(gamma_1)),zeros(1,length(gamma_2))]';
%--------------------------------------------------------------------------
end
%--------------------------------------------------------------------------
Nelem = size(triang,1);
Nodes = size(coord,1);
NDir  = size(DirNod,1);

%---------------------
%max length of each triangle
h = zeros(Nelem,1);
P = zeros(3,2); d=zeros(3,1);
%----------------------------
for iel=1:Nelem
    %-----------
    for iloc=1:3
        xglob=triang(iel,iloc);
        P(iloc,:)=coord(xglob);
    end
    %-----------
    for i=1:2
        d(i)=norm(P(i,:)-P(i+1,:));
    end
    %----------
    d(3)=norm(P(1,:)-P(3,:));
    h(iel)=max(d);
%----------------------------
end
%----------------------------
if nargin == 4
    if seeMesh
        TR=triangulation(triang,coord);
        triplot(TR);
    end
end
%--------------------------------------------------------------------------
end